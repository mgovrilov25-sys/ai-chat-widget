/**
 * AI Chat Widget Pro - Frontend JavaScript
 * New Design: Dark Gradient with Glassmorphism & Promo Sidebar
 */

(function($) {
    'use strict';
    
    // Глобальные переменные
    var sessionId = '';
    var isProcessing = false;
    var messageHistory = [];
    var debounceTimer;
    
    $(document).ready(function() {
        initChat();
    });
    
    /**
     * Инициализация чата
     */
    function initChat() {
        var $widget = $('#acwp-chat-widget');
        
        if (!$widget.length) {
            return;
        }
        
        // Генерируем или восстанавливаем session ID
        sessionId = getSessionId();
        
        // Отображаем приветственное сообщение
        showWelcomeMessage();
        
        // Привязываем обработчики событий
        bindEvents();
        
        // Фокус на поле ввода
        setTimeout(function() {
            $('#acwp-message-input').focus();
        }, 500);
    }
    
    /**
     * Получение/генерация session ID
     */
    function getSessionId() {
        var stored = localStorage.getItem('acwp_session_id');
        if (stored) {
            return stored;
        }
        var newId = 'acwp_' + generateId();
        localStorage.setItem('acwp_session_id', newId);
        return newId;
    }
    
    /**
     * Генерация случайного ID
     */
    function generateId() {
        return Math.random().toString(36).substring(2, 15) + 
               Math.random().toString(36).substring(2, 15);
    }
    
    /**
     * Привязка событий
     */
    function bindEvents() {
        // Отправка по клику
        $('#acwp-send-btn').on('click', function() {
            sendMessage();
        });
        
        // Отправка по Enter
        $('#acwp-message-input').on('keypress', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                sendMessage();
            }
        });
        
        // Debounce для ввода (опционально — можно использовать для аналитики)
        $('#acwp-message-input').on('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function() {
                // Можно добавить аналитику ввода
            }, 500);
        });
    }
    
    /**
     * Отправка сообщения
     */
    function sendMessage() {
        var $input = $('#acwp-message-input');
        var message = $input.val().trim();
        
        if (!message || isProcessing) {
            return;
        }
        
        // Очищаем поле ввода
        $input.val('');
        
        // Добавляем сообщение пользователя
        addMessage('user', message);
        
        // Сохраняем в историю
        messageHistory.push({
            role: 'user',
            content: message
        });
        
        // Показываем индикатор загрузки
        showTyping();
        
        // Отправляем на сервер
        isProcessing = true;
        
        $.ajax({
            url: acwpSettings.ajaxUrl,
            type: 'POST',
            data: {
                action: 'acwp_send_message',
                nonce: acwpSettings.nonce,
                message: message,
                session_id: sessionId
            },
            success: function(response) {
                hideTyping();
                
                if (response.success) {
                    // Обновляем session ID если нужно
                    if (response.data.session_id) {
                        sessionId = response.data.session_id;
                        localStorage.setItem('acwp_session_id', sessionId);
                    }
                    
                    // Добавляем ответ AI
                    var aiResponse = response.data.response;
                    addMessage('ai', aiResponse);
                    
                    // Сохраняем в историю
                    messageHistory.push({
                        role: 'assistant',
                        content: aiResponse
                    });
                    
                    // Ограничиваем историю (последние 10 сообщений)
                    if (messageHistory.length > 10) {
                        messageHistory = messageHistory.slice(-10);
                    }
                } else {
                    showError(response.data.message || 'Произошла ошибка');
                }
            },
            error: function(xhr, status, error) {
                hideTyping();
                showError('Ошибка соединения. Попробуйте позже.');
                console.error('ACWP Error:', error);
            },
            complete: function() {
                isProcessing = false;
            }
        });
    }
    
    /**
     * Добавление сообщения в чат
     */
    function addMessage(type, text) {
        var $container = $('#acwp-messages');
        var safeText = escapeHtml(text);
        
        // SVG иконки для аватарок
        var aiAvatarSvg = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>';
        
        var userAvatarSvg = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>';
        
        var avatarSvg = type === 'ai' ? aiAvatarSvg : userAvatarSvg;
        
        var messageHtml = '<div class="acwp-message acwp-message-' + type + '">' +
            '<div class="acwp-message-avatar">' + avatarSvg + '</div>' +
            '<div class="acwp-message-content">' + safeText + '</div>' +
            '</div>';
        
        // Убираем приветствие если оно есть
        $container.find('.acwp-welcome').remove();
        
        $container.append(messageHtml);
        scrollToBottom();
    }
    
    /**
     * Показать индикатор набора текста
     */
    function showTyping() {
        var $container = $('#acwp-messages');
        
        var aiAvatarSvg = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>';
        
        var typingHtml = '<div class="acwp-message acwp-message-ai acwp-typing-indicator">' +
            '<div class="acwp-message-avatar">' + aiAvatarSvg + '</div>' +
            '<div class="acwp-typing">' +
            '<span class="acwp-typing-dot"></span>' +
            '<span class="acwp-typing-dot"></span>' +
            '<span class="acwp-typing-dot"></span>' +
            '</div>' +
            '</div>';
        
        $container.append(typingHtml);
        scrollToBottom();
    }
    
    /**
     * Скрыть индикатор набора текста
     */
    function hideTyping() {
        $('#acwp-messages .acwp-typing-indicator').remove();
    }
    
    /**
     * Показать ошибку
     */
    function showError(message) {
        var $container = $('#acwp-messages');
        var errorHtml = '<div class="acwp-error">' + escapeHtml(message) + '</div>';
        
        $container.append(errorHtml);
        scrollToBottom();
        
        // Автоматически скрываем через 5 секунд
        setTimeout(function() {
            $container.find('.acwp-error').fadeOut(function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    /**
     * Приветственное сообщение (новый формат)
     */
    function showWelcomeMessage() {
        var $container = $('#acwp-messages');
        
        if ($container.children().length > 0) {
            return;
        }
        
        var agentName = typeof acwpSettings !== 'undefined' ? acwpSettings.agentName : 'ИИ Ассистент';
        
        var welcomeHtml = '<div class="acwp-welcome">' +
            '<div class="acwp-welcome-icon">👋</div>' +
            '<div class="acwp-welcome-text">' +
            'Как я могу увеличить ваши продажи сегодня?' +
            '</div>' +
            '</div>';
        
        $container.html(welcomeHtml);
    }
    
    /**
     * Прокрутка к последнему сообщению
     */
    function scrollToBottom() {
        var $messages = $('#acwp-messages');
        $messages.animate({
            scrollTop: $messages[0].scrollHeight
        }, 300);
    }
    
    /**
     * Получение текущего времени
     */
    function getCurrentTime() {
        var now = new Date();
        var hours = String(now.getHours()).padStart(2, '0');
        var minutes = String(now.getMinutes()).padStart(2, '0');
        return hours + ':' + minutes;
    }
    
    /**
     * Экранирование HTML
     */
    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
})(jQuery);
