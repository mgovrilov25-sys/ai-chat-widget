<?php
/**
 * Admin Settings for AI Chat Widget Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Добавление страницы настроек
 */
add_action( 'admin_menu', 'acwp_add_admin_menu' );
function acwp_add_admin_menu() {
    add_menu_page(
        'AI Chat Widget Pro',
        'AI Chat Widget',
        'manage_options',
        'ai-chat-widget-pro',
        'acwp_settings_page',
        'dashicons-format-chat',
        30
    );
}

/**
 * Регистрация настроек
 */
add_action( 'admin_init', 'acwp_register_settings' );
function acwp_register_settings() {
    // Основные настройки
    register_setting( 'acwp_settings_group', 'acwp_api_key' );
    register_setting( 'acwp_settings_group', 'acwp_system_prompt' );
    register_setting( 'acwp_settings_group', 'acwp_agent_name' );
    register_setting( 'acwp_settings_group', 'acwp_avatar_url' );
    
    // Внешний вид
    register_setting( 'acwp_settings_group', 'acwp_primary_color' );
    register_setting( 'acwp_settings_group', 'acwp_user_msg_color' );
    register_setting( 'acwp_settings_group', 'acwp_ai_msg_color' );
    register_setting( 'acwp_settings_group', 'acwp_max_height' );
    register_setting( 'acwp_settings_group', 'acwp_desktop_width' );
    
    // Telegram
    register_setting( 'acwp_settings_group', 'acwp_telegram_token' );
    register_setting( 'acwp_settings_group', 'acwp_telegram_chat_id' );
    register_setting( 'acwp_settings_group', 'acwp_leads_enabled' );
    
    // API
    register_setting( 'acwp_settings_group', 'acwp_ssl_verify' );
    register_setting( 'acwp_settings_group', 'acwp_yandex_folder_id' );
    register_setting( 'acwp_settings_group', 'acwp_api_provider' );
}

/**
 * Страница настроек
 */
function acwp_settings_page() {
    ?>
    <div class="wrap">
        <h1>AI Chat Widget Pro</h1>
        <p>Настройки AI чат-виджета с GigaChat интеграцией</p>
        
        <form method="post" action="options.php">
            <?php settings_fields( 'acwp_settings_group' ); ?>
            <?php do_settings_sections( 'acwp_settings_group' ); ?>
            
            <div class="acwp-tabs">
                <div class="acwp-tab-nav">
                    <a href="#general" class="acwp-tab-link active">Основные</a>
                    <a href="#appearance" class="acwp-tab-link">Внешний вид</a>
                    <a href="#telegram" class="acwp-tab-link">Telegram</a>
                    <a href="#api" class="acwp-tab-link">API</a>
                    <a href="#usage" class="acwp-tab-link">Использование</a>
                </div>
                
                <!-- Основные настройки -->
                <div id="general" class="acwp-tab-content active">
                    <table class="form-table">
                        <tr>
                            <th scope="row">API ключ GigaChat</th>
                            <td>
                                <input type="text" name="acwp_api_key" value="<?php echo esc_attr( get_option( 'acwp_api_key' ) ); ?>" class="regular-text">
                                <p class="description">Введите ваш API ключ от GigaChat (Yandex GPT)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Системный промпт</th>
                            <td>
                                <textarea name="acwp_system_prompt" rows="6" class="large-text"><?php echo esc_textarea( get_option( 'acwp_system_prompt' ) ); ?></textarea>
                                <p class="description">Инструкция для AI ассистента</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Имя агента</th>
                            <td>
                                <input type="text" name="acwp_agent_name" value="<?php echo esc_attr( get_option( 'acwp_agent_name', 'AI Ассистент' ) ); ?>" class="regular-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">URL аватара</th>
                            <td>
                                <input type="url" name="acwp_avatar_url" value="<?php echo esc_attr( get_option( 'acwp_avatar_url' ) ); ?>" class="regular-text">
                                <p class="description">URL изображения аватара (рекомендуется 80x80px)</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Внешний вид -->
                <div id="appearance" class="acwp-tab-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Основной цвет</th>
                            <td>
                                <input type="color" name="acwp_primary_color" value="<?php echo esc_attr( get_option( 'acwp_primary_color', '#4F46E5' ) ); ?>">
                                <code><?php echo esc_html( get_option( 'acwp_primary_color', '#4F46E5' ) ); ?></code>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Цвет сообщений пользователя</th>
                            <td>
                                <input type="color" name="acwp_user_msg_color" value="<?php echo esc_attr( get_option( 'acwp_user_msg_color', '#f3f4f6' ) ); ?>">
                                <code><?php echo esc_html( get_option( 'acwp_user_msg_color', '#f3f4f6' ) ); ?></code>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Цвет сообщений AI</th>
                            <td>
                                <input type="color" name="acwp_ai_msg_color" value="<?php echo esc_attr( get_option( 'acwp_ai_msg_color', '#e0f2fe' ) ); ?>">
                                <code><?php echo esc_html( get_option( 'acwp_ai_msg_color', '#e0f2fe' ) ); ?></code>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Максимальная высота секции (px)</th>
                            <td>
                                <input type="number" name="acwp_max_height" value="<?php echo intval( get_option( 'acwp_max_height', 600 ) ); ?>" min="200" max="1000" class="small-text">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Ширина секции desktop (px)</th>
                            <td>
                                <input type="number" name="acwp_desktop_width" value="<?php echo intval( get_option( 'acwp_desktop_width', 1000 ) ); ?>" min="600" max="1400" class="small-text">
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Telegram -->
                <div id="telegram" class="acwp-tab-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">Telegram Bot Token</th>
                            <td>
                                <input type="text" name="acwp_telegram_token" value="<?php echo esc_attr( get_option( 'acwp_telegram_token' ) ); ?>" class="regular-text">
                                <p class="description">Получите у @BotFather</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Telegram Chat ID</th>
                            <td>
                                <input type="text" name="acwp_telegram_chat_id" value="<?php echo esc_attr( get_option( 'acwp_telegram_chat_id' ) ); ?>" class="regular-text">
                                <p class="description">ID чата для уведомлений (можно получить у @userinfobot)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Отправка лидов</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="acwp_leads_enabled" <?php checked( get_option( 'acwp_leads_enabled' ), 'on' ); ?>>
                                    Включить отправку лидов в Telegram
                                </label>
                            </td>
                        </tr>
                    </table>
                    
                    <div class="acwp-leads-info">
                        <h3>Категории лидов</h3>
                        <table class="widefat">
                            <thead>
                                <tr>
                                    <th>Температура</th>
                                    <th>Ключевые слова</th>
                                    <th>Приоритет</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>🔥 Горячий</td>
                                    <td>купить, заказать, цена, стоимость, доставка, оплата, в корзину, куплю, хочу купить</td>
                                    <td>Высокий</td>
                                </tr>
                                <tr>
                                    <td>🟡 Тёплый</td>
                                    <td>интересно, подробнее, как работает, отзывы, цена?, есть в наличии?, скидка?</td>
                                    <td>Средний</td>
                                </tr>
                                <tr>
                                    <td>❄️ Холодный</td>
                                    <td>Приветствия, общие вопросы без покупки</td>
                                    <td>Низкий (не отправляется)</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- API -->
                <div id="api" class="acwp-tab-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">API Провайдер</th>
                            <td>
                                <select name="acwp_api_provider" id="acwp_api_provider">
                                    <option value="gigachat" <?php selected( get_option( 'acwp_api_provider', 'gigachat' ), 'gigachat' ); ?>>GigaChat (Сбер)</option>
                                    <option value="yandex" <?php selected( get_option( 'acwp_api_provider' ), 'yandex' ); ?>>Yandex GPT</option>
                                </select>
                                <p class="description">Выберите какой AI использовать</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Yandex Folder ID</th>
                            <td>
                                <input type="text" name="acwp_yandex_folder_id" value="<?php echo esc_attr( get_option( 'acwp_yandex_folder_id' ) ); ?>" class="regular-text">
                                <p class="description">ID каталога в Yandex Cloud (требуется для Yandex GPT)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Проверка SSL сертификатов</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="acwp_ssl_verify" <?php checked( get_option( 'acwp_ssl_verify' ), 'on' ); ?>>
                                    Отключить проверку SSL
                                </label>
                                <p class="description">Включите, если получаете ошибку "SSL certificate problem"</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Использование -->
                <div id="usage" class="acwp-tab-content">
                    <div class="acwp-usage-info">
                        <h3>Как использовать</h3>
                        <p>Вставьте шорткод в любую страницу или запись:</p>
                        <code>[ai_chat_widget]</code>
                        
                        <h4>Дополнительные параметры:</h4>
                        <ul>
                            <li><code>[ai_chat_widget height="500"]</code> — переопределить высоту</li>
                        </ul>
                        
                        <h4>В Elementor:</h4>
                        <p>Используйте виджет "Shortcode" и вставьте <code>[ai_chat_widget]</code></p>
                    </div>
                </div>
            </div>
            
            <?php submit_button( 'Сохранить настройки' ); ?>
        </form>
    </div>
    
    <style>
    .acwp-tabs {
        margin-top: 20px;
    }
    .acwp-tab-nav {
        border-bottom: 1px solid #c3c4c7;
        margin-bottom: 20px;
    }
    .acwp-tab-link {
        display: inline-block;
        padding: 10px 20px;
        text-decoration: none;
        color: #646970;
        border-bottom: 2px solid transparent;
        margin-bottom: -1px;
        font-weight: 500;
    }
    .acwp-tab-link:hover {
        color: #2271b1;
    }
    .acwp-tab-link.active {
        color: #2271b1;
        border-bottom-color: #2271b1;
    }
    .acwp-tab-content {
        display: none;
    }
    .acwp-tab-content.active {
        display: block;
    }
    .acwp-leads-info {
        margin-top: 30px;
        padding: 20px;
        background: #f0f6fc;
        border-radius: 4px;
    }
    .acwp-usage-info {
        padding: 20px;
        background: #f6f7f7;
        border-radius: 4px;
    }
    .acwp-usage-info code {
        background: #fff;
        padding: 5px 10px;
        border-radius: 3px;
    }
    </style>
    
    <script>
    jQuery(document).ready(function($) {
        $('.acwp-tab-link').on('click', function(e) {
            e.preventDefault();
            $('.acwp-tab-link').removeClass('active');
            $('.acwp-tab-content').removeClass('active');
            $(this).addClass('active');
            $($(this).attr('href')).addClass('active');
        });
    });
    </script>
    <?php
}