<?php
/**
 * Telegram Sender for Leads
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Класс для отправки лидов в Telegram
 */
class ACWP_Telegram_Sender {
    
    private $bot_token;
    private $chat_id;
    private $api_url = 'https://api.telegram.org/bot';
    
    public function __construct() {
        $this->bot_token = get_option( 'acwp_telegram_token' );
        $this->chat_id = get_option( 'acwp_telegram_chat_id' );
    }
    
    /**
     * Отправка лида в Telegram
     */
    public function send_lead( $lead_id, $session_id, $message, $temperature_data ) {
        if ( empty( $this->bot_token ) || empty( $this->chat_id ) ) {
            return false;
        }
        
        $page_url = isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( $_SERVER['HTTP_REFERER'] ) : 'Неизвестно';
        $client_ip = $this->get_client_ip();
        
        $text = $this->format_lead_message( $lead_id, $message, $temperature_data, $page_url, $client_ip );
        
        $result = $this->send_message( $text );
        
        // Обновляем статус отправки в БД
        if ( $result ) {
            global $wpdb;
            $table_name = $wpdb->prefix . 'acwp_leads';
            $wpdb->update(
                $table_name,
                array( 'sent_to_telegram' => 1 ),
                array( 'id' => $lead_id ),
                array( '%d' ),
                array( '%d' )
            );
        }
        
        return $result;
    }
    
    /**
     * Форматирование сообщения о лиде
     */
    private function format_lead_message( $lead_id, $message, $temperature_data, $page_url, $client_ip ) {
        $emoji = $temperature_data['emoji'];
        $label = $temperature_data['label'];
        $priority = $temperature_data['priority'];
        
        $priority_text = '';
        switch ( $priority ) {
            case 3:
                $priority_text = '⚡ Требует немедленной реакции!';
                break;
            case 2:
                $priority_text = '📋 Стоит обработать в течение дня';
                break;
            default:
                $priority_text = '📌 Обычный приоритет';
        }
        
        $text = <<<EOT
🚨 *НОВЫЙ ЛИД* #{$lead_id}

{$emoji} *Температура:* {$label}
{$priority_text}

👤 *Клиент:* Неизвестный
💬 *Сообщение:* 
```
{$message}
```

🌡️ *Статус:* Новое обращение
🔗 *Страница:* {$page_url}
🖥️ *IP:* {$client_ip}
🕐 *Время:* {$this->get_current_time()}
EOT;

        return $text;
    }
    
    /**
     * Отправка сообщения в Telegram
     */
    private function send_message( $text ) {
        $url = $this->api_url . $this->bot_token . '/sendMessage';
        
        $params = array(
            'chat_id'                  => $this->chat_id,
            'text'                     => $text,
            'parse_mode'               => 'Markdown',
            'disable_web_page_preview' => true,
        );
        
        $response = wp_remote_post( $url, array(
            'timeout'     => 30,
            'sslverify'   => false,
            'headers'     => array(
                'Content-Type' => 'application/json',
            ),
            'body'        => wp_json_encode( $params ),
        ) );
        
        if ( is_wp_error( $response ) ) {
            error_log( 'ACWP Telegram Error: ' . $response->get_error_message() );
            return false;
        }
        
        $status_code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        
        if ( $status_code !== 200 || ! isset( $body['ok'] ) || ! $body['ok'] ) {
            error_log( 'ACWP Telegram API Error: ' . wp_remote_retrieve_body( $response ) );
            return false;
        }
        
        return true;
    }
    
    /**
     * Получение IP клиента
     */
    private function get_client_ip() {
        $ip_keys = array( 'HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' );
        foreach ( $ip_keys as $key ) {
            if ( ! empty( $_SERVER[ $key ] ) ) {
                return sanitize_text_field( $_SERVER[ $key ] );
            }
        }
        return 'Неизвестно';
    }
    
    /**
     * Текущее время
     */
    private function get_current_time() {
        return current_time( 'd.m.Y H:i:s' );
    }
    
    /**
     * Тестирование соединения с Telegram
     */
    public function test_connection() {
        if ( empty( $this->bot_token ) ) {
            return new WP_Error( 'no_token', 'Токен бота не настроен' );
        }
        
        $url = $this->api_url . $this->bot_token . '/getMe';
        
        $response = wp_remote_get( $url, array( 
            'timeout'   => 30,
            'sslverify' => false,
        ) );
        
        if ( is_wp_error( $response ) ) {
            return $response;
        }
        
        $status_code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        
        if ( $status_code !== 200 || ! isset( $body['ok'] ) || ! $body['ok'] ) {
            return new WP_Error( 'api_error', 'Ошибка подключения к Telegram API' );
        }
        
        return true;
    }
    
    /**
     * Получение списка неотправленных лидов
     */
    public function get_pending_leads() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'acwp_leads';
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE sent_to_telegram = 0 AND priority >= 2 ORDER BY created_at DESC LIMIT %d",
                50
            )
        );
    }
}