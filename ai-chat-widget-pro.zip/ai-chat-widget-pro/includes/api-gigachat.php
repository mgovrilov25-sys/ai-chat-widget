<?php
/**
 * GigaChat API Integration
 *
 * Авторизация GigaChat работает в 2 этапа:
 * 1. POST на OAuth-эндпоинт с Authorization: Basic <base64_key> → получаем access_token
 * 2. POST на chat/completions с Authorization: Bearer <access_token>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ACWP_GigaChat_API {

    /**
     * Client Credentials ключ (Base64) из настроек плагина
     */
    private $client_credentials;

    /**
     * Эндпоинт получения токена
     */
    private $oauth_url = 'https://ngw.devices.sberbank.ru:9443/api/v2/oauth';

    /**
     * Эндпоинт чата
     */
    private $chat_url = 'https://gigachat.devices.sberbank.ru/api/v1/chat/completions';

    /**
     * Системный промпт
     */
    private $system_prompt;

    /**
     * Ключ кэша токена в WordPress transients
     */
    private $token_cache_key = 'acwp_gigachat_access_token';

    public function __construct() {
        $this->client_credentials = get_option( 'acwp_api_key' );
        $this->system_prompt      = get_option(
            'acwp_system_prompt',
            'Ты эксперт-помощник интернет-магазина. Отвечай кратко, предлагай товары, уточняй потребности клиента.'
        );
    }

    // -------------------------------------------------------------------------
    // Публичные методы
    // -------------------------------------------------------------------------

    /**
     * Отправить сообщение в GigaChat и получить ответ.
     *
     * @param string $message
     * @param array  $conversation_history  Массив ['role'=>..., 'content'=>...] предыдущих сообщений
     * @return string|WP_Error
     */
    public function send_message( $message, $conversation_history = array() ) {

        if ( empty( $this->client_credentials ) ) {
            return new WP_Error( 'no_api_key', 'API ключ GigaChat не настроен' );
        }

        // Шаг 1 — получаем (или берём из кэша) access_token
        $access_token = $this->get_access_token();
        if ( is_wp_error( $access_token ) ) {
            return $access_token;
        }

        // Шаг 2 — отправляем сообщение
        $messages = array_merge(
            array(
                array(
                    'role'    => 'system',
                    'content' => $this->system_prompt,
                ),
            ),
            $conversation_history,
            array(
                array(
                    'role'    => 'user',
                    'content' => $message,
                ),
            )
        );

        $payload = array(
            'model'       => 'GigaChat',
            'messages'    => $messages,
            'temperature' => 0.7,
            'max_tokens'  => 1000,
            'stream'      => false,
        );

        $response = wp_remote_post(
            $this->chat_url,
            array(
                'timeout'   => 30,
                'sslverify' => false,
                'headers'   => array(
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json',
                    'Authorization' => 'Bearer ' . $access_token,
                ),
                'body' => wp_json_encode( $payload ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status = wp_remote_retrieve_response_code( $response );
        $body   = wp_remote_retrieve_body( $response );
        $data   = json_decode( $body, true );

        // Токен мог протухнуть — сбрасываем кэш и пробуем ещё раз
        if ( $status === 401 ) {
            delete_transient( $this->token_cache_key );
            return new WP_Error( 'token_expired', 'Токен GigaChat истёк, попробуйте ещё раз' );
        }

        if ( $status !== 200 ) {
            $msg = isset( $data['error']['message'] )
                ? $data['error']['message']
                : 'Ошибка GigaChat API: HTTP ' . $status;
            return new WP_Error( 'api_error', $msg );
        }

        if ( ! isset( $data['choices'][0]['message']['content'] ) ) {
            return new WP_Error( 'invalid_response', 'Некорректный ответ от GigaChat API' );
        }

        return $data['choices'][0]['message']['content'];
    }

    /**
     * Отправить сообщение через Yandex GPT API.
     *
     * @param string $message
     * @param array  $conversation_history
     * @return string|WP_Error
     */
    public function send_message_yandex( $message, $conversation_history = array() ) {

        if ( empty( $this->client_credentials ) ) {
            return new WP_Error( 'no_api_key', 'API ключ не настроен' );
        }

        $yandex_url = 'https://llm.api.cloud.yandex.net/foundationModels/v1/completion';
        $folder_id  = get_option( 'acwp_yandex_folder_id', '' );

        $messages = array_merge(
            array(
                array(
                    'role' => 'system',
                    'text' => $this->system_prompt,
                ),
            ),
            $this->convert_history_to_yandex_format( $conversation_history ),
            array(
                array(
                    'role' => 'user',
                    'text' => $message,
                ),
            )
        );

        $payload = array(
            'modelUri'          => 'gpt://' . $folder_id . '/yandexgpt-lite',
            'completionOptions' => array(
                'stream'      => false,
                'temperature' => 0.7,
                'maxTokens'   => 1000,
            ),
            'messages' => $messages,
        );

        $response = wp_remote_post(
            $yandex_url,
            array(
                'timeout'   => 30,
                'sslverify' => false,
                'headers'   => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Api-Key ' . $this->client_credentials,
                    'x-folder-id'   => $folder_id,
                ),
                'body' => wp_json_encode( $payload ),
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $status = wp_remote_retrieve_response_code( $response );
        $body   = wp_remote_retrieve_body( $response );
        $data   = json_decode( $body, true );

        if ( $status !== 200 ) {
            $msg = isset( $data['error']['message'] )
                ? $data['error']['message']
                : 'Ошибка Yandex GPT API: HTTP ' . $status;
            return new WP_Error( 'api_error', $msg );
        }

        if ( ! isset( $data['result']['alternatives'][0]['message']['text'] ) ) {
            return new WP_Error( 'invalid_response', 'Некорректный ответ от Yandex GPT API' );
        }

        return $data['result']['alternatives'][0]['message']['text'];
    }

    /**
     * Проверить соединение с GigaChat.
     *
     * @return bool
     */
    public function test_connection() {
        $result = $this->send_message( 'Привет' );
        return ! is_wp_error( $result );
    }

    // -------------------------------------------------------------------------
    // Приватные методы
    // -------------------------------------------------------------------------

    /**
     * Получить действующий access_token.
     * Токен кэшируется в WordPress transients на 29 минут (живёт 30 мин).
     *
     * @return string|WP_Error
     */
    private function get_access_token() {

        // Проверяем кэш
        $cached = get_transient( $this->token_cache_key );
        if ( ! empty( $cached ) ) {
            return $cached;
        }

        // Уникальный UUID для RqUID (требование Сбера)
        $rq_uid = $this->generate_uuid();

        $response = wp_remote_post(
            $this->oauth_url,
            array(
                'timeout'   => 30,
                'sslverify' => false,
                'headers'   => array(
                    // Authorization: Basic <client_credentials>
                    'Authorization' => 'Basic ' . $this->client_credentials,
                    'Content-Type'  => 'application/x-www-form-urlencoded',
                    'Accept'        => 'application/json',
                    'RqUID'         => $rq_uid,
                ),
                // scope определяет версию модели: GIGACHAT_API_PERS (физ. лица) или GIGACHAT_API_CORP (юр. лица)
                'body' => 'scope=GIGACHAT_API_PERS',
            )
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error(
                'oauth_error',
                'Ошибка получения токена GigaChat: ' . $response->get_error_message()
            );
        }

        $status = wp_remote_retrieve_response_code( $response );
        $body   = wp_remote_retrieve_body( $response );
        $data   = json_decode( $body, true );

        if ( $status !== 200 ) {
            $msg = isset( $data['message'] )
                ? $data['message']
                : 'Ошибка OAuth GigaChat: HTTP ' . $status . ' | ' . $body;
            return new WP_Error( 'oauth_error', $msg );
        }

        if ( empty( $data['access_token'] ) ) {
            return new WP_Error( 'oauth_error', 'GigaChat не вернул access_token. Ответ: ' . $body );
        }

        $access_token = $data['access_token'];

        // expires_at приходит в миллисекундах — кэшируем на 29 минут
        set_transient( $this->token_cache_key, $access_token, 29 * MINUTE_IN_SECONDS );

        return $access_token;
    }

    /**
     * Генерация UUID v4 для заголовка RqUID.
     *
     * @return string
     */
    private function generate_uuid() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),
            mt_rand( 0, 0xffff ),
            mt_rand( 0, 0x0fff ) | 0x4000,
            mt_rand( 0, 0x3fff ) | 0x8000,
            mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
        );
    }

    /**
     * Конвертация истории сообщений в формат Yandex GPT.
     *
     * @param array $history
     * @return array
     */
    private function convert_history_to_yandex_format( $history ) {
        $converted = array();
        foreach ( $history as $msg ) {
            $converted[] = array(
                'role' => $msg['role'],
                'text' => $msg['content'],
            );
        }
        return $converted;
    }
}
