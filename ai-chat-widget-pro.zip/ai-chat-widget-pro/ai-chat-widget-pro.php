<?php
/**
 * Plugin Name: AI Chat Widget Pro
 * Description: AI чат-виджет с GigaChat интеграцией и лидогенерацией через Telegram
 * Version: 1.0.0
 * Author: OpenClaw
 * License: GPL v2 or later
 * Text Domain: ai-chat-widget-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ACWP_VERSION', '1.0.0' );
define( 'ACWP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ACWP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Подключение файлов
require_once ACWP_PLUGIN_DIR . 'includes/admin-settings.php';
require_once ACWP_PLUGIN_DIR . 'includes/api-gigachat.php';
require_once ACWP_PLUGIN_DIR . 'includes/telegram-sender.php';

/**
 * Активация плагина
 */
register_activation_hook( __FILE__, 'acwp_activate' );
function acwp_activate() {
    $default_options = array(
        'acwp_api_key'           => '',
        'acwp_system_prompt'     => 'Ты эксперт-помощник интернет-магазина. Отвечай кратко, предлагай товары, уточняй потребности клиента. Если видит интерес к покупке — переводи в горячую стадию.',
        'acwp_agent_name'        => 'AI Ассистент',
        'acwp_avatar_url'        => ACWP_PLUGIN_URL . 'assets/img/default-avatar.png',
        'acwp_primary_color'     => '#4F46E5',
        'acwp_user_msg_color'    => '#f3f4f6',
        'acwp_ai_msg_color'      => '#e0f2fe',
        'acwp_max_height'        => 600,
        'acwp_desktop_width'     => 1000,
        'acwp_telegram_token'    => '',
        'acwp_telegram_chat_id'  => '',
        'acwp_leads_enabled'     => 'off',
    );
    
    foreach ( $default_options as $option_name => $default_value ) {
        if ( false === get_option( $option_name ) ) {
            add_option( $option_name, $default_value );
        }
    }
    
    // Создаем таблицу для лидов
    acwp_create_leads_table();
}

/**
 * Создание таблицы лидов
 */
function acwp_create_leads_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'acwp_leads';
    $charset_collate = $wpdb->get_charset_collate();
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        session_id varchar(64) NOT NULL,
        message text NOT NULL,
        temperature varchar(20) NOT NULL DEFAULT 'cold',
        priority int(1) NOT NULL DEFAULT 1,
        page_url varchar(500) NOT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        sent_to_telegram tinyint(1) DEFAULT 0,
        PRIMARY KEY (id),
        KEY session_id (session_id),
        KEY created_at (created_at)
    ) $charset_collate;";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
}

/**
 * Деактивация плагина
 */
register_deactivation_hook( __FILE__, 'acwp_deactivate' );
function acwp_deactivate() {
    // Очистка при деактивации (опционально)
}

/**
 * Подключение скриптов и стилей
 */
add_action( 'wp_enqueue_scripts', 'acwp_enqueue_assets' );
function acwp_enqueue_assets() {
    wp_enqueue_style(
        'acwp-chat-style',
        ACWP_PLUGIN_URL . 'assets/css/chat-widget.css',
        array(),
        ACWP_VERSION
    );
    
    wp_enqueue_script(
        'acwp-chat-script',
        ACWP_PLUGIN_URL . 'assets/js/chat-widget.js',
        array( 'jquery' ),
        ACWP_VERSION,
        true
    );
    
    // Передача настроек в JS
    wp_localize_script( 'acwp-chat-script', 'acwpSettings', array(
        'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
        'nonce'         => wp_create_nonce( 'acwp_chat_nonce' ),
        'primaryColor'  => get_option( 'acwp_primary_color', '#4F46E5' ),
        'userMsgColor'  => get_option( 'acwp_user_msg_color', '#f3f4f6' ),
        'aiMsgColor'    => get_option( 'acwp_ai_msg_color', '#e0f2fe' ),
        'agentName'     => get_option( 'acwp_agent_name', 'AI Ассистент' ),
        'avatarUrl'     => get_option( 'acwp_avatar_url', ACWP_PLUGIN_URL . 'assets/img/default-avatar.png' ),
        'maxHeight'     => intval( get_option( 'acwp_max_height', 600 ) ),
        'desktopWidth'  => intval( get_option( 'acwp_desktop_width', 1000 ) ),
    ) );
}

/**
 * Шорткод для вставки виджета
 */
add_shortcode( 'ai_chat_widget', 'acwp_render_widget' );
function acwp_render_widget( $atts ) {
    $atts = shortcode_atts( array(
        'height' => '',
    ), $atts );
    
    $agent_name = esc_html( get_option( 'acwp_agent_name', 'ИИ Ассистент' ) );
    $max_height = intval( get_option( 'acwp_max_height', 600 ) );
    
    ob_start();
    ?>
    <div id="acwp-chat-widget" class="acwp-chat-section" style="--acwp-max-height: <?php echo $max_height; ?>px;">
        <div class="acwp-chat-container">
            <!-- Left Panel: Chat Interface (Glassmorphism) -->
            <div class="acwp-chat-main">
                <!-- Chat Header -->
                <div class="acwp-chat-header">
                    <div class="acwp-header-left">
                        <div class="acwp-header-avatar">
                            <svg viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                            </svg>
                        </div>
                        <div class="acwp-header-info">
                            <span class="acwp-header-name"><?php echo $agent_name; ?></span>
                            <span class="acwp-header-status">Онлайн</span>
                        </div>
                    </div>
                    <div class="acwp-header-actions">
                        <button type="button" class="acwp-header-btn" title="Без звука">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M11 5L6 9H2v6h4l5 4V5z"/>
                                <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>
                            </svg>
                        </button>
                        <button type="button" class="acwp-header-btn" title="Закрыть">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                </div>
                
                <!-- Messages Area -->
                <div class="acwp-chat-messages" id="acwp-messages"></div>
                
                <!-- Input Area -->
                <div class="acwp-chat-input-wrapper">
                    <input type="text" id="acwp-message-input" class="acwp-message-input" placeholder="Поправьте сообщение..." maxlength="500">
                    <button type="button" id="acwp-send-btn" class="acwp-send-btn">
                        <svg viewBox="0 0 24 24" fill="currentColor">
                            <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                        </svg>
                    </button>
                </div>
            </div>
            
            <!-- Right Panel: Promo Sidebar -->
            <div class="acwp-promo-sidebar">
                <!-- Person Image -->
                <div class="acwp-promo-person">
                    <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=300&fit=crop" alt="Алекс Грант">
                </div>
                
                <!-- Yellow Speech Bubble -->
                <div class="acwp-promo-bubble">
                    НАПИШИТЕ В ЧАТ!<br>ЗАДАЙТЕ ЛЮБОЙ ВОПРОС
                </div>
                
                <!-- Bio -->
                <div class="acwp-promo-bio">
                    <div class="acwp-promo-name">Алекс Грант</div>
                    <div class="acwp-promo-subtitle">Эксперт по ИИ</div>
                </div>
                
                <!-- Headline -->
                <div class="acwp-promo-headline">
                    РАЗБЛОКИРУЙТЕ<br>ВАШ РОСТ СЕЙЧАС!
                </div>
                
                <!-- Countdown Timer -->
                <div class="acwp-promo-countdown">
                    <div class="acwp-countdown-item">
                        <div class="acwp-countdown-number">00</div>
                        <div class="acwp-countdown-label">Часы</div>
                    </div>
                    <div class="acwp-countdown-item">
                        <div class="acwp-countdown-number">50</div>
                        <div class="acwp-countdown-label">Мин</div>
                    </div>
                    <div class="acwp-countdown-item">
                        <div class="acwp-countdown-number">48</div>
                        <div class="acwp-countdown-label">Сек</div>
                    </div>
                </div>
                
                <!-- CTA Button -->
                <button type="button" class="acwp-promo-cta">
                    ПОЛУЧИТЬ ПЕРСОНАЛЬНУЮ<br>СТРАТЕГИЮ БЕСПЛАТНО
                </button>
                
                <!-- Footer -->
                <div class="acwp-promo-footer">
                    <div class="acwp-promo-trust">
                        <svg viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z"/>
                        </svg>
                        Доверие
                    </div>
                    <div class="acwp-promo-social">
                        <svg viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                        </svg>
                        Социальность
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * AJAX обработчик отправки сообщения
 */
add_action( 'wp_ajax_acwp_send_message', 'acwp_handle_message' );
add_action( 'wp_ajax_nopriv_acwp_send_message', 'acwp_handle_message' );

function acwp_handle_message() {
    // Проверка nonce
    if ( ! wp_verify_nonce( $_POST['nonce'], 'acwp_chat_nonce' ) ) {
        wp_send_json_error( array( 'message' => 'Ошибка безопасности' ) );
    }
    
    $message = isset( $_POST['message'] ) ? sanitize_textarea_field( $_POST['message'] ) : '';
    $session_id = isset( $_POST['session_id'] ) ? sanitize_text_field( $_POST['session_id'] ) : '';
    
    if ( empty( $message ) ) {
        wp_send_json_error( array( 'message' => 'Сообщение не может быть пустым' ) );
    }
    
    if ( empty( $session_id ) ) {
        $session_id = acwp_generate_session_id();
    }
    
    // Определяем температуру лида
    $temperature_data = acwp_analyze_temperature( $message );
    
    // Сохраняем лид если не холодный
    if ( $temperature_data['priority'] >= 2 ) {
        acwp_save_lead( $session_id, $message, $temperature_data );
    }
    
    // Получаем ответ от GigaChat или Yandex
    $api = new ACWP_GigaChat_API();
    $api_provider = get_option( 'acwp_api_provider', 'gigachat' );
    
    if ( $api_provider === 'yandex' ) {
        $response = $api->send_message_yandex( $message );
    } else {
        $response = $api->send_message( $message );
    }
    
    if ( is_wp_error( $response ) ) {
        wp_send_json_error( array( 'message' => $response->get_error_message() ) );
    }
    
    wp_send_json_success( array(
        'response'   => $response,
        'session_id' => $session_id,
    ) );
}

/**
 * Генерация ID сессии
 */
function acwp_generate_session_id() {
    return 'acwp_' . wp_generate_password( 16, false );
}

/**
 * Анализ температуры сообщения
 */
function acwp_analyze_temperature( $message ) {
    $message_lower = mb_strtolower( $message, 'UTF-8' );
    
    // Горячие ключевые слова
    $hot_keywords = array( 'купить', 'заказать', 'цена', 'стоимость', 'доставка', 'оплата', 'в корзину', 'куплю', 'хочу купить' );
    
    // Тёплые ключевые слова
    $warm_keywords = array( 'интересно', 'подробнее', 'как работает', 'отзывы', 'цена?', 'есть в наличии?', 'скидка?' );
    
    // Проверяем на горячие
    foreach ( $hot_keywords as $keyword ) {
        if ( strpos( $message_lower, $keyword ) !== false ) {
            return array(
                'temperature' => 'hot',
                'priority'    => 3,
                'emoji'       => '🔥',
                'label'       => 'ГОРЯЧИЙ',
            );
        }
    }
    
    // Проверяем на тёплые
    foreach ( $warm_keywords as $keyword ) {
        if ( strpos( $message_lower, $keyword ) !== false ) {
            return array(
                'temperature' => 'warm',
                'priority'    => 2,
                'emoji'       => '🟡',
                'label'       => 'ТЁПЛЫЙ',
            );
        }
    }
    
    // Холодный по умолчанию
    return array(
        'temperature' => 'cold',
        'priority'    => 1,
        'emoji'       => '❄️',
        'label'       => 'ХОЛОДНЫЙ',
    );
}

/**
 * Сохранение лида в БД
 */
function acwp_save_lead( $session_id, $message, $temperature_data ) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'acwp_leads';
    
    $wpdb->insert(
        $table_name,
        array(
            'session_id'  => $session_id,
            'message'     => $message,
            'temperature' => $temperature_data['temperature'],
            'priority'    => $temperature_data['priority'],
            'page_url'    => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( $_SERVER['HTTP_REFERER'] ) : '',
        ),
        array( '%s', '%s', '%s', '%d', '%s' )
    );
    
    $lead_id = $wpdb->insert_id;
    
    // Отправка в Telegram если включено
    if ( get_option( 'acwp_leads_enabled' ) === 'on' ) {
        $telegram = new ACWP_Telegram_Sender();
        $telegram->send_lead( $lead_id, $session_id, $message, $temperature_data );
    }
    
    return $lead_id;
}